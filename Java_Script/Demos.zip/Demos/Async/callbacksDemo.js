//A callback is a function passed as an argument to another function.

function fetchData(callback){
    console.log("Fetching data....");

    setTimeout(function(){
        let data="Student Data Loaded";
        callback(data);
    },2000);
}

fetchData(function(result){
console.log(result);
});