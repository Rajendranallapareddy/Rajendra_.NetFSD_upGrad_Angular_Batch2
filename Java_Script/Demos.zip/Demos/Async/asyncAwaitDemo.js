//async and await are modern JavaScript keywords that provide a cleaner, more synchronous-looking syntax for handling asynchronous operations

function fetchData() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve("Student Data Loaded");
    }, 2000);
  });
}

async function getData(){
    console.log("Fetching data...");
    try{
        let result=await fetchData();
        console.log(result);

    }catch(error){
        console.log(error);
    }
}

getData();

//Much cleaner
//Easy error handling using try/catch
//Best modern approach