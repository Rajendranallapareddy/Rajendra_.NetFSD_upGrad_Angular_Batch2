//A Promise represents a value that may be available now, later, or never.

function fetchData(){
    return new Promise(function(resolve,reject){
        console.log("Fetching data...");

        setTimeout(function(){
            let success=false;

            if(success){
                resolve("Student Data Loaded");
            }else{
                reject("Error while loading data");
            }
        },2000);
    });
}

fetchData()
.then(function(result){
    console.log(result);//this message will be printed if task is resolved
})
.catch(function(error){
    console.log(error); //this message will be printed if task is rejected
});