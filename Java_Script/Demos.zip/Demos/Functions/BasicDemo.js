
//function declaration
function greet(){
    //defination
    console.log("Hello,welcome to JS");
}

//function calling
greet();