
//Immediately Invoked Function Expression

(function(){
    console.log("This is IIFE");
})();

//param IIFE
(function(a,b){
    console.log(a*b);
})(10,20);

//IIFE using Arrow Functions
((a,b)=>console.log(a*b))(2,5);