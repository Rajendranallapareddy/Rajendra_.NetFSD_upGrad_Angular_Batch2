
function Add(num1,num2){

    if(num1>0 && num2>0){
        return num1+num2;
    }else{
        return 0;
    }
}

let result=Add(10,30);
console.log(`The sum of ${10} and ${30}=${result}`);
//console.log(Add(10,30));
