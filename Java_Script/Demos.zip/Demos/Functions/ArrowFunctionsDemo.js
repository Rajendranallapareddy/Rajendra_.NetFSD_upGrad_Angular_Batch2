
//Arrow Function
const square=(num)=>num*num;

const mul=(a,b)=>a*b;

const message=(a,b)=>console.log(a*b);

console.log(square(10));

console.log(mul(2,10));

message(10,20);