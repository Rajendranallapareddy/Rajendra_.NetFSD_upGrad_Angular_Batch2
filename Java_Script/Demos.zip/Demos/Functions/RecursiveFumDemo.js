var result;
function factorial(n){
    if(n==0){
        return 1;
    }else{
        result=n*factorial(n-1);//4*3*2*1
        return result;
    }
}

let finalResult=factorial(4);
console.log(finalResult);