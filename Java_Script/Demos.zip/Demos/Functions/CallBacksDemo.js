
function greet(name,callback){
    //execute logic before calling callback
    console.log(`hello:${name}`);

    //callback function
    callback();
}

function greetMessage(){
    console.log("welcome to callback function");
}

greet("Shoaib",greetMessage)