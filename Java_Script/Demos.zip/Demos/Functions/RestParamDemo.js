
function ShowDetails(name,...optionalDetails){
    console.log(name);//mandatory param
    console.log(optionalDetails);
   for (const element of optionalDetails) {
    console.log(element);
   }
}

ShowDetails("Scott"); //Scott []
ShowDetails("Scott",45,"Pune"); //Scott 45 Pune