
//Global Scope
let globalVar="I am Global";

function showGlobal(){
    console.log(globalVar);
}

showGlobal();
console.log(globalVar);

//Function Scope
function testFunctionScope(){
    let functionVar="I am inside function";
    console.log(functionVar);

    if(true){
        console.log(functionVar);

        //block scoped variable
        let blockVar="I am inside if block";
        console.log(blockVar);
    }

   // console.log(blockVar);//error
}

testFunctionScope();
//console.log(functionVar);//error

//Shadowing
let name="Global Name";

function demoShadow(){
    let name="Local Name";
    console.log(name);
}

demoShadow();
console.log(name);