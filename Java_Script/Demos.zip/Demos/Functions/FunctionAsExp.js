
//Function expression
const greet=function(name){
    return `Hello, ${name}`
}

//Function Call
const result=greet("Shoaib");
console.log(result);