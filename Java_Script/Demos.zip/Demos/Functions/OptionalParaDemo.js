
function greet(name="Shoaib") //optional param
{
    console.log(`hello,${name}`);
}

function Add(num2,num1=30){
    console.log(num1+num2);
}

greet();
greet("Scott");
Add(10);
Add(20,50);