
//default export
export default function greet(name){
    return `Hello:${name}`;
};

export function message(){
    return "hello world";
}