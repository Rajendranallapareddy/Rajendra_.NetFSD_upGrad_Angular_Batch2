
//default exporting a class

export default class User{
    constructor(){

    }
    greet(){
        return "Hello from User class";
    }
}