
import sayHello from './greet.js'
import { message } from './greet.js';
import User from './User.js'
import config from './config.js';

console.log(sayHello("Shoaib"));
console.log(message());

let user1=new User();
console.log(user1.greet());

console.log(config.appName);