//default exporting object

export default{
    appName:"Student Portal",
    version:"1.0",
    author:"Admin"
}