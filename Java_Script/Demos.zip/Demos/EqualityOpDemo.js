
//Loose Equality
console.log(5=="5"); //true
console.log(5==6); //false;
console.log(true==1);//true
console.log(null==undefined);//true 
console.log(""==0);//true

//strict equality
console.log(5==="5"); //false
console.log(true===1);//false
console.log(null===undefined);//false
console.log(""===0);//false

//Object.is()
const isEqual= Object.is(10,"10");
console.log(isEqual);