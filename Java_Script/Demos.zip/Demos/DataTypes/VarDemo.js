
function testScope(){
    if(true){
        //function scoped var
        var a=10;
        let b=20;
        console.log(`value of a inside if block ${a}`);
        console.log(`value of b inside if block ${b}`);
    }

    a++;
    console.log(`value of a outside if block ${a}`);

    console.log(`value of b outside if block ${b}`);//error

}

testScope();