function constFunTest(){
    let r=5;
    const PI=3.14;//const must be init., it can not be assigned
    //PI=3.15;//error
    let aoc=PI*r*r;
    console.log("Area of Circle:",aoc);
}

constFunTest();

const student={
    id:100,
    name:"Shoaib"
}

//you can get a data
console.log("Id:",student.id);
console.log("Name:",student.name);

//you can set a data
//student.id=101; //error

const skills=["HTML","CSS"];