//Number
let age=30;
console.log("Age:",age);
console.log("Type of age:",typeof age);

//String
let name="Shoaib";
console.log("Name:",name);
console.log("Type of name:",typeof name);

//Boolean
let isTrainer=true;
console.log("is Trainer:",isTrainer);
console.log("Type of isTrainer:",typeof isTrainer);

//undefined
let city;
console.log("City:",city);
console.log("Type of city:",typeof city);

//Null
let salary=null;
console.log("Salary:",salary);
console.log("Type of Salary",typeof salary);

//Object
let student={
    id:100,
    name:"Shoaib",
    course:".Net",
    address:{
        street:"M.G Road",
        city:"Nashik",
        state:"Maharashtra"
    },
    department:"Training"
}

console.log("Id:",student.id);
console.log("City:",student.city);
console.log("Course:",student.course);
console.log("Street:",student.address.street);
console.log("City:",student.address.city);
console.log("State:",student.address.state);
console.log("Department:",student.department);
console.log("Type of student:",typeof student);

//Array
let skills=["HTML","CSS","JS"];
console.log("Skills:",skills);
console.log("Type of skills:",typeof skills);

//BigInt
let bigNumber=1234567891011;
console.log("bigNumber:",bigNumber);
console.log("Type of bigNumber",typeof bigNumber);

//String Interpolation
let firstName="Shoaib";
let dept="Training";
console.log(`My Name is ${firstName} and I Belongs to ${dept}`);