
function testLetFun(){
    if(true){
        //block-scoped variable (for if block)
        let y=10;
        var a=10;
        console.log(`value of y inside if block ${y}`);
         console.log(`value of a inside if block ${a}`);

        if(true){
        //block-scoped variable (for nested if block )
            let y=20;
            console.log(`value of y inside nested if block ${y}`);

            a=30;
            console.log(`value of a inside nested if block ${a}`);

        }
    }

     console.log(`value of y outside if block ${y}`);//error
}

testLetFun();