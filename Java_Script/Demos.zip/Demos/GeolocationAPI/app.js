//to fetch current location
function getLocation(){
    var output = document.getElementById("output");

    if (!navigator.geolocation) {
        output.innerHTML = "Geolocation is not supported by your browser.";
        return;
    }

    output.innerHTML = "Fetching location...";

    navigator.geolocation.getCurrentPosition(success, error);
}

//Show longitude and latitude on Sucess
function success(position) {

    var latitude = position.coords.latitude;
    var longitude = position.coords.longitude;

    document.getElementById("output").innerHTML =
        "Latitude: " + latitude +
        "<br>Longitude: " + longitude;

    showMap(latitude, longitude);
}


//Error handling
function error(err) {

    switch (err.code) {
        case err.PERMISSION_DENIED:
            alert("User denied location access.");
            break;

        case err.POSITION_UNAVAILABLE:
            alert("Location information is unavailable.");
            break;

        case err.TIMEOUT:
            alert("Request timed out.");
            break;

        default:
            alert("Unknown error occurred.");
    }
}

//Show map

function showMap(lat, lon) {

    var mapFrame = document.getElementById("map");

    mapFrame.innerHTML =
        '<iframe width="100%" height="400" ' +
        'src="https://maps.google.com/maps?q=' +
        lat + ',' + lon +
        '&z=15&output=embed">' +
        '</iframe>';
}