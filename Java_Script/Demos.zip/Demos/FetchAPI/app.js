function loadUsers(){
    const tableBody=document.querySelector("#userTable tbody");
    tableBody.innerHTML="";

    fetch("https://jsonplaceholder.typicode.com/users")
    .then(response=>{
        if(!response.ok){
            throw new Error("Error");
        }
        return response.json();
    })
    .then(data=>{
        data.forEach(user => {
            const row=document.createElement("tr");
            row.innerHTML=`
            <td>${user.id}</td>
            <td>${user.name}</td>
            <td>${user.email}</td>
            <td>${user.address.city}</td>
            `;
            tableBody.appendChild(row);

        });
    }).catch(error=>{
        console.error(error);
    });
}