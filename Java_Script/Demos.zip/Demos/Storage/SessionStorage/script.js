
//select elements
const nameInput=document.getElementById("name");
const emailInput=document.getElementById("email");
const output=document.getElementById("output");

//save data
document.getElementById("saveBtn").addEventListener("click",function(){
    sessionStorage.setItem("userName",nameInput.value);
    sessionStorage.setItem("userEmail",emailInput.value);
    alert("Data Saved in Session Storage");
});

//show data
document.getElementById("showBtn").addEventListener("click",function(e){
e.preventDefault();
let name=sessionStorage.getItem("userName");
let email=sessionStorage.getItem("userEmail");
output.innerHTML="Name:"+name+" and Email:"+email;
});

//remove sepecific data
document.getElementById("removeBtn").addEventListener("click",function(){
    sessionStorage.removeItem("userName");
    alert("Name Removed");
});

//Clear All session storage

document.getElementById("clearBtn").addEventListener("click",function(){
    sessionStorage.clear();
    alert("All session data cleared");
});