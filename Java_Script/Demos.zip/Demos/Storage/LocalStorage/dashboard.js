
function getUserName(){
    let username=localStorage.getItem("username");
    document.getElementById("username").innerHTML=username;
}

function LogOut(){
    localStorage.removeItem("username");
    localStorage.removeItem("isLoggedIn");
    window.location.href="Login.html";
}