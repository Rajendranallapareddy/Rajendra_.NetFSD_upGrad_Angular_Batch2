
function login(){
    let username=document.getElementById("username").value;
    let password=document.getElementById("password").value;

    if(username==="admin" && password==="1234"){
        localStorage.setItem("isLoggedIn","true");
        localStorage.setItem("username",username);
        window.location.href="dashboard.html";
    }else{
        alert("Invalid Credentials");
    }
}