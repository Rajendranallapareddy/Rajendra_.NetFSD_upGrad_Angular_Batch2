function PrintNumber1To10(){
    for (let i=1;i<=10;i++) {

        let result=(i%2==0);
        if(result){
            console.log(`Even=${i}`);
        }else{
            console.log(`Odd=${i}`);
        }
      
    }
}

PrintNumber1To10();