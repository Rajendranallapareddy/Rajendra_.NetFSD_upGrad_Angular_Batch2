function PrintArray(){
    let nums=[45,56,45,67,45,45];
    for(let temp of nums){
        console.log(temp);
    }
}

PrintArray();