function PrintOddAndEven(number){
    let i=1; //init

    //condition
    while(i<=number){
        if(i%2==0){
            console.log(`Even=${i}`);
            
        }else{
            console.log(`Odd=${i}`);
        }
        i++; //updation of counter variable
    }
}

let number=15;
PrintOddAndEven(number);