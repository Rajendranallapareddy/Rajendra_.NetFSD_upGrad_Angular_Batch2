
function PrintArray(){
    let nums=[34,56,67,78,89];
    for(let temp in nums){
        console.log(nums[temp]);
    }
}

PrintArray();