function PrintOddAndEven(number){
    let i=16; //init

    do{
        if(i%2==0){
            console.log(`Even=${i}`);
        }else{
            console.log(`Odd=${i}`);
        }

        i++;//updation of counter variable
    }
    while(i<=number);//condition

}

let num=15;
PrintOddAndEven(num);