
        const paraElement1=document.getElementsByClassName("info");
        console.log(paraElement1[0].innerHTML);

        const paraelement2=document.getElementById("para2");
        console.log(paraelement2.innerHTML);

        const divElement=document.getElementsByTagName("div");
        console.log(divElement[0].innerHTML);