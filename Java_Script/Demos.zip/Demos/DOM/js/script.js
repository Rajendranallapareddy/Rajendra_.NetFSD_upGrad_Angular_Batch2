
document.getElementById("employeeForm").addEventListener("submit",function(e){
    e.preventDefault();
    clearErrors();
   

    let isValid=true;

    if(!validateEmpCode()) isValid=false;
    if(!validateEmpName()) isValid=false;
    if(!validateDOB()) isValid=false;
    if(!validateEmail()) isValid=false;
    if(!validatePassword()) isValid=false;
    if(!validateConfirmPassword()) isValid=false;
    if(isValid){
       // document.getElementById("formMessage").textContent="Registration Successful!"
       alert("Registration Successful!");
    }

});

function validateEmpCode(){
    let empCode=document.getElementById("empCode").value;
    let regex=/^EMP\d{3}$/; //EMP123
    if(!regex.test(empCode)){
        showError("empCodeError","Invalid Employee Code")
        return false;
    }
    return true;
}

function validateEmpName(){
    let name=document.getElementById("empName").value;
    if(name===""){
        showError("empNameError","Please enter an employee name")
        return false;
    }
    return true;
}

function validateDOB(){
    let dob=document.getElementById("dob").value;
    if(dob===""){
        showError("dobError","Invalid Date of Birth");
        return false;
    }
   

    return true;
}

function validateEmail(){
    let email=document.getElementById("email").value;
    if(email===""){
        showError("emailError","Email is required");
        return false;
    }

    return true;
}

function validatePassword(){
    let password=document.getElementById("password").value;
    if(password===""){
        showError("passwordError","Invalid Password");
        return false;
    }
    if(password.length<8){
        showError("passwordError","password should be 8 char. minimum");
        return false;
    }
    return true;
}

function validateConfirmPassword(){
    let confirmPassword=document.getElementById("confirmPassword").value;
    let password=document.getElementById("password").value;
    if(confirmPassword===""){
        showError("confirmPasswordError","Confirm Password Required");
        return false;
    }
    if(password!=confirmPassword){
        showError("confirmPasswordError","Password and Confirm Password should be matched");
        return false;
    }
    return true;
}
//helper methods
function clearErrors(){
    let errors=document.querySelectorAll(".error");
    for(let element of errors){
        element.textContent="";
    }

    document.getElementById("formMessage").textContent="";
}

function showError(elementId,message){
    document.getElementById(elementId).textContent=message;
}