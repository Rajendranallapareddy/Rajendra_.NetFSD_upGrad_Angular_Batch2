
let db;

//Open Database
let request=indexedDB.open("StudentDB",1);
request.onupgradeneeded=function(event){
    db=event.target.result;
    db.createObjectStore("students",{keyPath:"id"});
};

request.onsuccess=function(event){
    db=event.target.result;
    console.log("Database Ready");
}

//Insert
document.getElementById("insertBtn").addEventListener("click",function(){

    let id=Number(document.getElementById("id").value);
    let name=document.getElementById("name").value;

    let transaction=db.transaction(["students"],"readwrite");
    let store=transaction.objectStore("students");
    store.add({id:id,name:name});
    alert("Student Inserted");
});

//Update
document.getElementById("updateBtn").addEventListener("click",function(){
    let id=Number(document.getElementById("id").value);
    let name=document.getElementById("name").value;

    let transaction=db.transaction(["students"],"readwrite");
    let store=transaction.objectStore("students");
    store.put({id:id,name:name});
    alert("Student Updated");
});

//Select
document.getElementById("selectBtn").addEventListener("click",function(e){
    e.preventDefault();
    let transaction=db.transaction(["students"],"readonly");
    let store=transaction.objectStore("students");
   let request= store.getAll();
   

   request.onsuccess=function(){
    let students=request.result;
     console.log(request.result);
    let list=document.getElementById("studentList");
    list.innerHTML="";

    students.forEach(function(std) {
        let li=document.createElement("li");
        li.textContent=`${std.id}-${std.name}`;
        list.appendChild(li);
    });
   }
});

//Delete
document.getElementById("deleteBtn").addEventListener("click",function(){
let id=Number( document.getElementById("id").value);

 let transaction=db.transaction(["students"],"readwrite");
let store=transaction.objectStore("students");
    store.delete(id);
    alert("Student Deleted");
});
