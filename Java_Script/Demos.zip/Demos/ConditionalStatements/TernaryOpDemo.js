function personalStatus(age){
    let result=age>=18? "Major": "Minor";
    console.log(result);
}

personalStatus(20);

function Message1(){
    //your complex logic goes here
    console.log("Person is major");
}

function Message2(){
    //your complex logic goes here
    console.log("Person is Minor");
}
function PrintPersonStatus(personAge){
    let age=personAge;

    let result= age>=18 ? Message1() :Message2();

    console.log(result);
}

PrintPersonStatus(20);
