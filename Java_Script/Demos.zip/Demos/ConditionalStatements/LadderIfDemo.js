
function CheckNumber(number){
    if(number>0){
        console.log("number is positive");
    }
    else if(number<0){
        console.log("number is negative");
    }else{
        console.log("number is 0");
    }
}

function GetDay(number){
    if(number==1){
        console.log("Monday");
    }
    else if (number==2){
        console.log("Tuesday");
    }
    else if (number==3){
        console.log("Wednesday");
    }
    else{
        console.log("Invalid Number");
    }
}

CheckNumber(12);
GetDay(3);