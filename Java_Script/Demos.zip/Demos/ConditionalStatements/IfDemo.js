
function personalStatus(age){
    let result=age>=18;

    if(result){
        console.log("Person is Major");
    }else{
        console.log("Person is Minor");
    }

    if(age>=60){
        console.log("Senior citizen");
    }
}

personalStatus(40);