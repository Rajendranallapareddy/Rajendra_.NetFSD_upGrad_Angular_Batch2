
//named export

//it contains business logic

export function add(a,b){
    return a+b;
}

export function multiply(a,b){
    return a*b;
}