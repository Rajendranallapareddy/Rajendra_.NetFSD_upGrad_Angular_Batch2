
//This is connector between module (math.js) and index.html

import {add,multiply} from './math.js'

const num1=document.getElementById("num1");
const num2=document.getElementById("num2");
const result=document.getElementById("result");

document.getElementById("addBtn").addEventListener("click",()=>{
result.textContent=`Result:${add(Number(num1.value) ,Number(num2.value))}`;
});

document.getElementById("mulBtn").addEventListener("click",()=>{
result.textContent=`Result:${multiply(Number(num1.value) ,Number(num2.value))}`;
});

