
    let numbers=[11,22,33];

    //To add element at the end
    numbers.push(4);
    console.log(numbers);
    for (const num of numbers) {
        console.log(`${num}`);
    }

    //To remove element from top
    numbers.pop();//will remove 4
    console.log("After removing 4:");
     for (const num of numbers) {
        console.log(`${num}`);
    }

    //To add element in the begining
    numbers.unshift(6);
    console.log("after adding element at the begining");
   
     for (const num of numbers) {
        console.log(`${num}`);
    }

    //To remove element from beginning
    numbers.shift();
    console.log("after removing element from beginning");
    for (const num of numbers) {
        console.log(`${num}`);
    }

    //Loop through array
    let students=["scott","smith","jhone","adam"];
    students.forEach(function(name){
        console.log(name);
    });

    //transform array
    let nums=[1,2,3];
    let doubled=nums.map(function(num){
        return num*2;
    });
    console.log(doubled);

    //filter data
    let myNumbers=[10,20,30,40];
    let result=myNumbers.filter(function(num){
        return num >20;
    });

    console.log(result);

    //To convert to single value
    let values=[3,5,6,7,8];
    let sum=values.reduce(function(total,num){
        return total+num;
    });

    console.log(sum);

    //Searching methods
    let fruits=["apple","banana","mango"];
    console.log(fruits.includes("banana"));

    console.log(fruits.indexOf("mango"));

    let result1=values.find(num=>num>5);
    console.log(result1);

    //Sorting and Reversing
    let data=[4,6,2,1,8,9];
    data.sort();
    console.log(data);

    data.reverse();
    console.log(data);

    //To combine arrays
    let a=[1,2];
    let b=[3,4];
    let c=a.concat(b);
    console.log(c);

    //To copy part of array
    let evenNumbers=[2,4,6,8];
    let part=evenNumbers.slice(3);
    console.log(part);

    //To convert array to string
    console.log(fruits.join(","));